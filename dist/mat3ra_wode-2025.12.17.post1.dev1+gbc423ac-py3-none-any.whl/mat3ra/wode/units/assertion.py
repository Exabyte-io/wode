from mat3ra.esse.models.workflow.unit.assertion import AssertionUnitSchema

from .unit import Unit


class AssertionUnit(Unit, AssertionUnitSchema):
    pass
