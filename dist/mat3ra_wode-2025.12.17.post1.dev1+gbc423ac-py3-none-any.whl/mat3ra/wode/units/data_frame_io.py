from mat3ra.esse.models.workflow.unit.io import Subtype

from .. import IOUnit


class DataFrameIOUnit(IOUnit):
    subtype: str = Subtype.dataFrame
