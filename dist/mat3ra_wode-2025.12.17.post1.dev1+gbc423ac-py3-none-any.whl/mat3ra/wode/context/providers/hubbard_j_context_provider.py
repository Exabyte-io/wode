from .hubbard_u_context_provider import HubbardUContextProvider


class HubbardJContextProvider(HubbardUContextProvider):
    """
    Context provider for Hubbard J settings.
    """
